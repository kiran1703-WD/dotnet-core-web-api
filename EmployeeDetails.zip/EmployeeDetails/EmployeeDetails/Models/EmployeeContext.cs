﻿using Microsoft.EntityFrameworkCore;

namespace EmployeeDetails.Models
{
    public class EmployeeDeatilsContext : DbContext
    {
        public EmployeeDeatilsContext(DbContextOptions<EmployeeDeatilsContext> options)
            : base(options)
        {
        }

        public DbSet<EmployeeDetails.Models.Employee> Employee { get; set; }
    }
}