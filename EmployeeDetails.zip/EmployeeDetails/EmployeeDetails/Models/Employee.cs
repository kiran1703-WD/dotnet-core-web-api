﻿namespace EmployeeDetails.Models
{
    public class Employee
    {
        public long Id { get; set; }
        public string EmployeeName { get; set; }
    
    }
}
