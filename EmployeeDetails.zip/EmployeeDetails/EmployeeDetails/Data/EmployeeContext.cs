﻿using Microsoft.EntityFrameworkCore;
namespace EmployeeDetails.Models
{
    public class EmployeeDetailContext : DbContext
    {
        public EmployeeDetailContext(DbContextOptions<EmployeeDetailContext> options)
            : base(options)
        {

        }
        public DbSet<EmployeeDetails.Models.Employee> Employee { get; set; }
    }

   
}
